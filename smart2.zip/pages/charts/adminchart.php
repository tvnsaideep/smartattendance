<?php
session_start();
$user=$_SESSION['username'];?><!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Smart Attendance</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="../../vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="../../vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="../../vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="../../css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="images/favicon.png" />
<?php
$conn=new mysqli("localhost","root","","attn");
$totcse=0;
$totece=0;
$toteee=0;
$totme=0;
$totc=0;
$csecount=0;$ececount=0;$eeecount=0;$mecount=0;$ccount=0;
$sel=mysqli_query($conn,"select * from percentage");
while($row=mysqli_fetch_assoc($sel))
{
  if($row['branch']=='cse')
  {
    $totcse=$totcse+$row['attnper'];
    $csecount=$csecount+1;
  }
  elseif ($row['branch']=='ece') {
    $totece=$totece+$row['attnper'];
    $ececount=$ececount+1;
  }
  elseif ($row['branch']=='mech') {
    $totme=$totme+$row['attnper'];
    $mecount=$mecount+1;

  }
  elseif ($row['branch']=='civil') {
    $totc=$totc+$row['attnper'];
    $ccount=$ccount+1;

  }
  elseif ($row['branch']=='eee') {
    $toteee=$toteee+$row['attnper'];
    $eeecount=$eeecount+1;

  }
}
$divc=($totcse/$csecount)*100;
$dive=($totece/$ececount)*100;
$divm=($totme/$mecount)*100;
$divci=($totc/$ccount)*100;
$divee=($toteee/$eeecount)*100;

function myfunction($divc,$dive,$divm,$divci,$divee)
{
  echo'
<script>
 function myfunction() {
   var chart1 = new CanvasJS.Chart("chartContainer1", {
   theme: "light2", // "light1", "light2", "dark1", "dark2"
   exportEnabled: true,
   animationEnabled: true,
   title: {
     text: "Attendance percentage"
   },
   data: [{
     type: "pie",
     startAngle: 25,
     toolTipContent: "<b>{label}</b>: {y}%",
     showInLegend: "true",
     legendText: "{label}",
     indexLabelFontSize: 16,
     indexLabel: "{label} - {y}%",
     dataPoints: [
       { y: '. $divc.', label: "cse" },
       { y: '.$dive.', label: "ece" },
       { y: '.$divm.', label: "Mech" },
       { y: '.$divee.', label: "Eee" },
       { y: '.$divci.', label: "Civil" }
     ]
   }]
   });
  chart1.render();

  var chart2 = new CanvasJS.Chart("chartContainer2", {
  	animationEnabled: true,
  	title: {
  		text: "Average Attendance"
  	},
  	axisX: {
  		interval: 1
  	},
  	axisY: {
  		title: "Branch",
  		scaleBreaks: {
  			type: "wavy",
  			customBreaks: [{
  				startValue: 80,
  				endValue: 210
  				},
  				{
  					startValue: 230,
  					endValue: 600
  				}
  		]}
  	},
  	data: [{
  		type: "bar",
  		toolTipContent: "<img src=\"https://canvasjs.com/wp-content/uploads/images/gallery/javascript-column-bar-charts/\"{url}\"\" style=\"width:40px; height:20px;\"> <b>{label}</b><br>Budget: ${y}bn<br>{gdp}% of GDP",
  		dataPoints: [
  			{ label: "cse", y:'.$divc.' },
  			{ label: "ece", y: '.$dive.'},
  			{ label: "civil", y: '.$divci.'},
  			{ label: "Mech", y: '.$divm.' },
  			{ label: "EEE", y: '.$divee.' }
  		]
  	}]
  });
chart2.render();

}
</script>';
}
?>
</head>

<body onload="myfunction()">
  <div class="container-scroller">
    <!-- partial:../../partials/_navbar.html -->
    <nav class="navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="text-center navbar-brand-wrapper d-flex align-items-top justify-content-center">
        <a class="navbar-brand brand-logo" href="../../index.html">
          <img src="../../images/log.png" alt="logo" />
        </a>
        <a class="navbar-brand brand-logo-mini" href="../../index.html">
          <img src="../../images/logo-mini.svg" alt="logo" />
        </a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center">
        <ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">
          <li class="nav-item">
            <a href="../charts/schedule.php" class="nav-link">Schedule
              <span class="badge badge-primary ml-1">New</span>
            </a>
          </li>
          <li class="nav-item active">
            <a href="../charts/adminchart.php" class="nav-link">
              <i class="mdi mdi-elevation-rise"></i>Reports</a>
          </li>
        </ul>
        <ul class="navbar-nav navbar-nav-right">
          <li class="nav-item dropdown">

            <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="messageDropdown">
              <div class="dropdown-item">
                <p class="mb-0 font-weight-normal float-left">You have  unread mails
                </p>
                <span class="badge badge-info badge-pill float-right">View all</span>
              </div>
              <?php
              $count=0;
              $curdate=date("Y-m-d");

              $msgq=mysqli_query($conn,"select * from messages where date='$curdate'");
              while($msgrow=mysqli_fetch_assoc($msgq))
              {
                if($msgrow['name']==$user)
                {
                  echo '
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <img src="login/images/icons/avatar.png" alt="image" class="profile-pic">
                </div>
                <div class="preview-item-content flex-grow">
                  <h6 class="preview-subject ellipsis font-weight-medium text-dark">ADMIN
                    <span class="float-right font-weight-light small-text">Today</span>
                  </h6>
                  <p class="font-weight-light small-text">'.$msgrow['message'].'
                  </p>
                </div>
              </a>';
              $count=$count+1;
            }
            } ?>
            </div>
            <a class="nav-link count-indicator dropdown-toggle" id="messageDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
              <i class="mdi mdi-file-document-box"></i>
              <span class="count"><?php echo $count;?></span>
            </a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link count-indicator dropdown-toggle" id="notificationDropdown" href="#" data-toggle="dropdown">
              <i class="mdi mdi-bell"></i>
              <span class="count">1</span>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="notificationDropdown">
              <a class="dropdown-item">
                <p class="mb-0 font-weight-normal float-left">You have  new notifications
                </p>
                <span class="badge badge-pill badge-warning float-right">View all</span>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-success">
                    <i class="mdi mdi-alert-circle-outline mx-0"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <h6 class="preview-subject font-weight-medium text-dark">Your remainder</h6>
                  <p class="font-weight-light small-text">
                    Just now
                  </p>
                </div>
              </a><!--
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-warning">
                    <i class="mdi mdi-comment-text-outline mx-0"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <h6 class="preview-subject font-weight-medium text-dark">Settings</h6>
                  <p class="font-weight-light small-text">
                    Private message
                  </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-info">
                    <i class="mdi mdi-email-outline mx-0"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <h6 class="preview-subject font-weight-medium text-dark">New user registration</h6>
                  <p class="font-weight-light small-text">
                    2 days ago
                  </p>
                </div>
              </a>
            </div>-->
          </li>
          <li class="nav-item dropdown d-none d-xl-inline-block">
            <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
              <span class="profile-text">Hello, <?php echo $_SESSION['username'];?>!</span>
              <img class="img-xs rounded-circle" src="../../login/images/icons/avatar.png" alt="Profile image">
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
              <a class="dropdown-item p-0" href="setremainder.php">
                <div class="d-flex border-bottom">
                  <!--<div class="py-3 px-4 d-flex align-items-center justify-content-center">
                    <i class="mdi mdi-bookmark-plus-outline mr-0 text-gray"></i>
                  </div>
                  <div class="py-3 px-4 d-flex align-items-center justify-content-center border-left border-right">
                    <i class="mdi mdi-account-outline mr-0 text-gray"></i>
                  </div>-->
                  <div class="py-3 px-4 d-flex align-items-center justify-content-center">
                    <i class="mdi mdi-alarm-check mr-0 text-gray">set remainder</i>
                  </div>
                </div>
              </a>
              <!--<a class="dropdown-item mt-2">
                Manage Accounts
              </a>-->
              <a href="../forms/changepassword.php"class="dropdown-item">
                Change Password
              </a>
            <!--  <a class="dropdown-item">
                Check Inbox
              </a>-->
              <a href="../../login/logout.php"class="dropdown-item">
                Sign Out
              </a>
            </div>
          </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="icon-menu"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:../../partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item nav-profile">
            <div class="nav-link">
              <div class="user-wrapper">
                <div class="profile-image">
                  <img src="../../login/images/icons/avatar.png" alt="profile image">
                </div>
                <div class="text-wrapper">
                  <p class="profile-name"><?php echo $_SESSION['username'];?></p>
                  <div>
                    <small class="designation text-muted"></small>
                    <span class="status-indicator online"></span>
                  </div>
                </div>
              </div>
              <!--<a href="take_attn.ph">
              <button class="btn btn-success btn-block">Take Attendance
                <i class="mdi mdi-plus"></i>
              </button>
            </a>-->
            </div>
          </li>


          <li class="nav-item Active">
            <a class="nav-link" href="../../admin_dashboard.php">
              <i class="menu-icon mdi mdi-television"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../forms/addstudent.php">
              <i class="menu-icon mdi mdi-backup-restore"></i>
              <span class="menu-title">Add Student</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../forms/addstaff.php">
              <i class="menu-icon mdi mdi-backup-restore"></i>
              <span class="menu-title">Add Staff</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../forms/notify.php">
              <i class="menu-icon mdi mdi-backup-restore"></i>
              <span class="menu-title">Notify</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../tables/send_msg.php">
              <i class="menu-icon mdi mdi-backup-restore"></i>
              <span class="menu-title">Send Messages</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../charts/adminchart.php">
              <i class="menu-icon mdi mdi-chart-line"></i>
              <span class="menu-title">Reports</span>
            </a>
          </li>
        </ul>
      </nav>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-lg-6 grid-margin stretch-card">
              <div id="chartContainer1" style="height: 300px; width: 100%;"><?php myfunction($divc,$dive,$divm,$divci,$divee);?></div>
                <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
            </div>
            <div class="col-lg-6 grid-margin stretch-card">
              <div id="chartContainer2" style="height: 300px; width: 100%;"></div>
                <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
            </div>
          </div>
        <!--  <div class="row">
            <div class="col-lg-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Area chart</h4>
                  <canvas id="areaChart" style="height:250px"></canvas>
                </div>
              </div>
            </div>
            <div class="col-lg-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Doughnut chart</h4>
                  <canvas id="doughnutChart" style="height:250px"></canvas>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Pie chart</h4>
                  <canvas id="pieChart" style="height:250px"></canvas>
                </div>
              </div>
            </div>
            <div class="col-lg-6 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Scatter chart</h4>
                  <canvas id="scatterChart" style="height:250px"></canvas>
                </div>
              </div>
            </div>
          </div>-->
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:../../partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
              <a href="" target="_blank">Smat Attendance</a>. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with
              <i class="mdi mdi-heart text-danger"></i>
            </span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="../../vendors/js/vendor.bundle.base.js"></script>
  <script src="../../vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="../../js/off-canvas.js"></script>
  <script src="../../js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <script src="../../js/chart.js"></script>
  <!-- End custom js for this page-->
</body>

</html>

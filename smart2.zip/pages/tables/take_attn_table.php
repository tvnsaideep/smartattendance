<?php
session_start();
$user=$_SESSION['username'];
$conn= new mysqli("localhost","root","","attn") or die('connecting error'.$conn->connect_error);
$date=date('y-m-d');
if(isset($_POST['submit']))
{
  $array1=$_POST['present'];
  if($array1)
  {
    foreach($_POST['present'] as $key=>$present)
    {
      $studentname=$_POST['fname'][$key];
      $branch=$_POST['branch'][$key];
      $year=$_POST['year'][$key];
      $sec=$_POST['sec'][$key];
      $rollnum=$_POST['roll'][$key];
      $sel=mysqli_query($conn,"INSERT INTO `attn_day`(`fullname`,`rollnum` ,`date`, `attn_status`, `branch`, `year`,`sec`) VALUES ('$studentname','$rollnum','$date','$present','$branch','$year','$sec')");
      $al=mysqli_query($conn,"insert into status(name,stat,date) values('$user','1','$date')");
    }

  }
  if($sel)
  {
    echo '<script>alert("Attendance Submitted");</script>';
  }
}
 ?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Smart Attendance</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="../../vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="../../vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="../../vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="../../css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="images/favicon.png" />
</head>

<body>
  <div class="container-scroller">
    <!-- partial:../../partials/_navbar.html -->
    <nav class="navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="text-center navbar-brand-wrapper d-flex align-items-top justify-content-center">
        <a class="navbar-brand brand-logo" href="../../index.html">
          <img src="../../images/log.png" alt="logo" />
        </a>
        <a class="navbar-brand brand-logo-mini" href="../../index.html">
          <img src="../../images/logo-mini.svg" alt="logo" />
        </a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center">
        <ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">
          <li class="nav-item">
            <a href="../charts/schedule.php" class="nav-link">Schedule
              <span class="badge badge-primary ml-1">New</span>
            </a>
          </li>
          <li class="nav-item active">
            <a href="../charts/chart.php" class="nav-link">
              <i class="mdi mdi-elevation-rise"></i>Reports</a>
          </li>
        </ul>
        <ul class="navbar-nav navbar-nav-right">
          <li class="nav-item dropdown">

            <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="messageDropdown">
              <div class="dropdown-item">
                <p class="mb-0 font-weight-normal float-left">You have  unread mails
                </p>
                <span class="badge badge-info badge-pill float-right">View all</span>
              </div>
              <?php
              $count=0;
              $curdate=date("Y-m-d");

              $msgq=mysqli_query($conn,"select * from messages where date='$curdate'");
              while($msgrow=mysqli_fetch_assoc($msgq))
              {
                if($msgrow['name']==$user)
                {
                  echo '
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <img src="login/images/icons/avatar.png" alt="image" class="profile-pic">
                </div>
                <div class="preview-item-content flex-grow">
                  <h6 class="preview-subject ellipsis font-weight-medium text-dark">ADMIN
                    <span class="float-right font-weight-light small-text">Today</span>
                  </h6>
                  <p class="font-weight-light small-text">'.$msgrow['message'].'
                  </p>
                </div>
              </a>';
              $count=$count+1;
            }
            } ?>
            </div>
            <a class="nav-link count-indicator dropdown-toggle" id="messageDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
              <i class="mdi mdi-file-document-box"></i>
              <span class="count"><?php echo $count;?></span>
            </a>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link count-indicator dropdown-toggle" id="notificationDropdown" href="#" data-toggle="dropdown">
              <i class="mdi mdi-bell"></i>
              <span class="count">4</span>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="notificationDropdown">
              <a class="dropdown-item">
                <p class="mb-0 font-weight-normal float-left">You have 4 new notifications
                </p>
                <span class="badge badge-pill badge-warning float-right">View all</span>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-success">
                    <i class="mdi mdi-alert-circle-outline mx-0"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <h6 class="preview-subject font-weight-medium text-dark">Your remainder</h6>
                  <p class="font-weight-light small-text">
                    Just now
                  </p>
                </div>
              </a><!--
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-warning">
                    <i class="mdi mdi-comment-text-outline mx-0"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <h6 class="preview-subject font-weight-medium text-dark">Settings</h6>
                  <p class="font-weight-light small-text">
                    Private message
                  </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-info">
                    <i class="mdi mdi-email-outline mx-0"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <h6 class="preview-subject font-weight-medium text-dark">New user registration</h6>
                  <p class="font-weight-light small-text">
                    2 days ago
                  </p>
                </div>
              </a>
            </div>-->
          </li>
          <li class="nav-item dropdown d-none d-xl-inline-block">
            <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
              <span class="profile-text">Hello, <?php echo $_SESSION['username'];?>!</span>
              <img class="img-xs rounded-circle" src="../../login/images/icons/avatar.png" alt="Profile image">
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
              <a class="dropdown-item p-0" href="setremainder.php">
                <div class="d-flex border-bottom">
                  <!--<div class="py-3 px-4 d-flex align-items-center justify-content-center">
                    <i class="mdi mdi-bookmark-plus-outline mr-0 text-gray"></i>
                  </div>
                  <div class="py-3 px-4 d-flex align-items-center justify-content-center border-left border-right">
                    <i class="mdi mdi-account-outline mr-0 text-gray"></i>
                  </div>-->
                  <div class="py-3 px-4 d-flex align-items-center justify-content-center">
                    <i class="mdi mdi-alarm-check mr-0 text-gray">set remainder</i>
                  </div>
                </div>
              </a>
              <!--<a class="dropdown-item mt-2">
                Manage Accounts
              </a>-->
              <a href="pages/forms/changepassword.php"class="dropdown-item">
                Change Password
              </a>
            <!--  <a class="dropdown-item">
                Check Inbox
              </a>-->
              <a href="login/logout.php"class="dropdown-item">
                Sign Out
              </a>
            </div>
          </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="icon-menu"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:../../partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item nav-profile">
            <div class="nav-link">
              <div class="user-wrapper">
                <div class="profile-image">
                  <img src="../../login/images/icons/avatar.png" alt="profile image">
                </div>
                <div class="text-wrapper">
                  <p class="profile-name"><?php echo $_SESSION['username'];?></p>
                  <div>
                    <small class="designation text-muted"></small>
                    <span class="status-indicator online"></span>
                  </div>
                </div>
              </div>
              <a href="take_attn.ph">
              <button class="btn btn-success btn-block">Take Attendance
                <i class="mdi mdi-plus"></i>
              </button>
            </a>
            </div>
          </li>


          <li class="nav-item Active">
            <a class="nav-link" href="../../index.php">
              <i class="menu-icon mdi mdi-television"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../charts/chart.php">
              <i class="menu-icon mdi mdi-chart-line"></i>
              <span class="menu-title">Reports</span>
            </a>
          </li>
        </ul>
      </nav>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-sm-2 grid-margin stretch-card">
              <div class="input-group">
            <label>Branch</label>
            &nbsp;
              <select id="mybranch" name="mybranch"onchange="myfunction1()"class="form-control">
                <option>Branch</option>
                <option value="cse">CSE</option>
                <option value="ece">ECE</option>
                <option value="me">Mech</option>
                <option value="ce">CIVIL</option>
                <option value="eee">EEE</option>
              </select>
            </div>

            </div>
            <div class="col-sm-2 grid-margin stretch-card">
              <div class="input-group">
            <label>year :</label>
            &nbsp;
              <select name="myselect"id="myselect" onchange="myfunction2()"class="form-control">
                <option>year</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
              </select>
            </div>

            </div>
            <div class="col-sm-2 grid-margin stretch-card">
              <div class="input-group">
            <label>sec:</label>
            &nbsp;
              <select name="myselect1" id="myselect1" onchange="myfunction()"class="form-control">
                <option>section</option>
                <option value="a">A</option>
                <option value="b">B</option>
                <option value="c">C</option>
                <option value="d">D</option>
              </select>
            </div>

            </div>
          </div>

              <script>
              var x='';
              var y='';
              var  z='';
              function myfunction1() {
                 x=document.getElementById("mybranch").value;
               }
               function myfunction2(){
                 y=document.getElementById("myselect").value;
              }
              function myfunction(){
                z=document.getElementById("myselect1").value;
                window.location.href="http://localhost/puppy/pages/tables/take_attn_table.php?val="+x+"&sec="+z+"&yr="+y;
                }
              </script>
              <?php

               $year=$_GET['yr'];
               $sec=$_GET['sec'];
               $branch=$_GET['val'];
               ?>

          <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Take Attendance now</h4>

                  <div class="table-responsive">
                    <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>Student </th>

                          <th>branch</th>
                          <th>RollNumber</th>
                          <th>present</th>
                          <th>Absent</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        $conn= new mysqli("localhost","root","","attn") or die('connecting error'.$conn->connect_error);
                        $sel=mysqli_query($conn,"select * from percentage");
                        //$ysel=mysqli_query($conn,"select * from attn_day where date='2018-06-26'");
                      //  $rows=mysqli_fetch_assoc($ysel);
                        $count1=0;
                        $count2=0;
                        while($row=mysqli_fetch_assoc($sel))
                        {
                          if(($row['branch']==$branch)&&($row['year']==$year)&&($row['sec']==$sec))
                          {
                      ?>
                      <form method="POST" action="">
                         <tbody>
                           <tr>
                           <td><?php echo $row['fullname'];?></td>
                           <input type="hidden" name="fname[]" value="<?php echo $row['fullname'];?>">
                           <td><?php echo $row['branch'];?></td>
                           <input type="hidden" name="branch[]" value="<?php echo $branch;?>">
                           <input type="hidden" name="year[]" value="<?php echo $year;?>">
                           <input type="hidden" name="sec[]" value="<?php echo $sec;?>">
                           <td><?php echo $row['rollnum'];?></td>
                           <input type="hidden" name="roll[]" value="<?php echo $row['rollnum'];?>">
                           <td><input type="radio" name="present[<?php echo $count1;?>]" value="1"></td>
                           <td><input type="radio" name="present[<?php echo $count2;?>]" value="0"></td>
                         </tr>
                       </tbody>
                           <?php
                            $count1++;
                            $count2++;
                         }
                       } ?>
                       </table>
                     </div>
                     <div align="right">
                        <input type="submit" class="btn btn-success" name="submit" value="submit" id="submit">
                      </div>
                      </form>
                      <script>

                      </script>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:../../partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
              <a href="http://www.bootstrapdash.com/" target="_blank">Bootstrapdash</a>. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with
              <i class="mdi mdi-heart text-danger"></i>
            </span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="../../vendors/js/vendor.bundle.base.js"></script>
  <script src="../../vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="../../js/off-canvas.js"></script>
  <script src="../../js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <!-- End custom js for this page-->
</body>

</html>

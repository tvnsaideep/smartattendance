<?php
session_start();
$user=$_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Star Admin Free Bootstrap-4 Admin Dashboard Template</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="../../vendors/iconfonts/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="../../vendors/css/vendor.bundle.base.css">
  <link rel="stylesheet" href="../../vendors/css/vendor.bundle.addons.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <link rel="stylesheet" href="../../vendors/icheck/skins/all.css">
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="../../css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="../../images/favicon.png" />
</head>

<body>
  <div class="container-scroller">
    <!-- partial:../../partials/_navbar.html -->
    <nav class="navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
      <div class="text-center navbar-brand-wrapper d-flex align-items-top justify-content-center ">
        <a class="navbar-brand brand-logo" href="index.php">
          <img src="../../images/log.png" alt="logo" />
        </a>
        <a class="navbar-brand brand-logo-mini" href="index.html">
          <img src="images/logo-mini.svg" alt="logo" />
        </a>
      </div>
      <div class="navbar-menu-wrapper d-flex align-items-center">
        <ul class="navbar-nav navbar-nav-left header-links d-none d-md-flex">
          <li class="nav-item">
            <a href="#" class="nav-link">Schedule
              <span class="badge badge-primary ml-1">New</span>
            </a>
          </li>

          <li class="nav-item active">
            <a href="../charts/adminchart.php" class="nav-link">
              <i class="mdi mdi-elevation-rise"></i>Reports</a>
          </li>

        </ul>
        <ul class="navbar-nav navbar-nav-right">
          <li class="nav-item dropdown">

            <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="messageDropdown">
              <div class="dropdown-item">
                <p class="mb-0 font-weight-normal float-left">You have  unread mails
                </p>
                <span class="badge badge-info badge-pill float-right">View all</span>
              </div>
              <?php
               $count=0;
              $curdate=date("Y-m-d");

              $msgq=mysqli_query($conn,"select * from messages where date='$curdate'");
              while($msgrow=mysqli_fetch_assoc($msgq))
              {
                if($msgrow['name']==$user)
                {
                  echo '
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <img src="login/images/icons/avatar.png" alt="image" class="profile-pic">
                </div>
                <div class="preview-item-content flex-grow">
                  <h6 class="preview-subject ellipsis font-weight-medium text-dark">ADMIN
                    <span class="float-right font-weight-light small-text">Today</span>
                  </h6>
                  <p class="font-weight-light small-text">'.$msgrow['message'].'
                  </p>
                </div>
              </a>';
              $count=$count+1;
            }
            } ?>
            </div>
            <a class="nav-link count-indicator dropdown-toggle" id="messageDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
              <i class="mdi mdi-file-document-box"></i>
              <span class="count"><?php echo $count;?></span>
            </a>
          </li>
          <!--
          <li class="nav-item dropdown">
            <a class="nav-link count-indicator dropdown-toggle" id="notificationDropdown" href="#" data-toggle="dropdown">
              <i class="mdi mdi-bell"></i>
              <span class="count">4</span>
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown preview-list" aria-labelledby="notificationDropdown">
              <a class="dropdown-item">
                <p class="mb-0 font-weight-normal float-left">You have 4 new notifications
                </p>
                <span class="badge badge-pill badge-warning float-right">View all</span>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-success">
                    <i class="mdi mdi-alert-circle-outline mx-0"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <h6 class="preview-subject font-weight-medium text-dark">Application Error</h6>
                  <p class="font-weight-light small-text">
                    Just now
                  </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-warning">
                    <i class="mdi mdi-comment-text-outline mx-0"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <h6 class="preview-subject font-weight-medium text-dark">Settings</h6>
                  <p class="font-weight-light small-text">
                    Private message
                  </p>
                </div>
              </a>
              <div class="dropdown-divider"></div>
              <a class="dropdown-item preview-item">
                <div class="preview-thumbnail">
                  <div class="preview-icon bg-info">
                    <i class="mdi mdi-email-outline mx-0"></i>
                  </div>
                </div>
                <div class="preview-item-content">
                  <h6 class="preview-subject font-weight-medium text-dark">New user registration</h6>
                  <p class="font-weight-light small-text">
                    2 days ago
                  </p>
                </div>
              </a>
            </div>
          </li>-->
          <li class="nav-item dropdown d-none d-xl-inline-block">
            <a class="nav-link dropdown-toggle" id="UserDropdown" href="#" data-toggle="dropdown" aria-expanded="false">
              <span class="profile-text">Hello, <?php echo "ADMIN"?>!</span>
              <img class="img-xs rounded-circle" src="../../login/images/icons/avatar.png" alt="Profile image">
            </a>
            <div class="dropdown-menu dropdown-menu-right navbar-dropdown" aria-labelledby="UserDropdown">
              <a class="dropdown-item p-0" href="setremainder.php">
                <div class="d-flex border-bottom">
                  <!--<div class="py-3 px-4 d-flex align-items-center justify-content-center">
                    <i class="mdi mdi-bookmark-plus-outline mr-0 text-gray"></i>
                  </div>
                  <div class="py-3 px-4 d-flex align-items-center justify-content-center border-left border-right">
                    <i class="mdi mdi-account-outline mr-0 text-gray"></i>
                  </div>-->
                  <div class="py-3 px-4 d-flex align-items-center justify-content-center">
                    <i class="mdi mdi-alarm-check mr-0 text-gray">set remainder</i>
                  </div>
                </div>
              </a>
              <!--<a class="dropdown-item mt-2">
                Manage Accounts
              </a>-->
              <a href="changepassword.php"class="dropdown-item">
                Change Password
              </a>
            <!--  <a class="dropdown-item">
                Check Inbox
              </a>-->
              <a href="../../login/logout.php"class="dropdown-item">
                Sign Out
              </a>
            </div>
          </li>
        </ul>
        <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-toggle="offcanvas">
          <span class="icon-menu"></span>
        </button>
      </div>
    </nav>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item nav-profile">
            <div class="nav-link">
              <div class="user-wrapper">
                <div class="profile-image">
                  <img src="../../login/images/icons/avatar.png" alt="profile image">
                </div>
                <div class="text-wrapper">
                  <p class="profile-name"><?php echo "ADMIN";?></p>
                  <div>
                    <small class="designation text-muted"><?php echo $_SESSION['branch'];?></small>
                    <span class="status-indicator online"></span>
                  </div>
                </div>
              </div>
              <a href="../tables/take_attn.php"<button class="btn btn-success btn-block">Take Attendance
                <i class="mdi mdi-plus"></i>
              </button></a>
            </div>
          </li>
          <li class="nav-item Active">
            <a class="nav-link" href="index.php">
              <i class="menu-icon mdi mdi-television"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="addstudent.php">
              <i class="menu-icon mdi mdi-backup-restore"></i>
              <span class="menu-title">Add Student</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="addstaff.php">
              <i class="menu-icon mdi mdi-backup-restore"></i>
              <span class="menu-title">Add Staff</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="notify.php">
              <i class="menu-icon mdi mdi-backup-restore"></i>
              <span class="menu-title">Notify</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="../charts/adminchart.php">
              <i class="menu-icon mdi mdi-chart-line"></i>
              <span class="menu-title">Reports</span>
            </a>
          </li>
    <!--      <li class="nav-item">
            <a class="nav-link" href="pages/tables/basic-table.html">
              <i class="menu-icon mdi mdi-table"></i>
              <span class="menu-title">Status</span>
            </a>
          </li>-->


        </ul>
      </nav>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-md-12 d-flex align-items-stretch grid-margin">
              <div class="row flex-grow">
                <div class="col-12">
                  <div class="card">
                    <div class="card-body">
                      <h4 class="card-title">Add a new staff</h4>
                      <p class="card-description">
                      </p>
                      <form method="POST" class="forms-sample">
                        <div class="form-group">
                          <label for="exampleInputEmail1">Full Name</label>
                          <input type="text" name="fn"class="form-control" id="exampleInputEmail1" placeholder="Enter Full name">
                        </div>
                        <div class="form-group">
                          <label for="exampleInputPassword1">password</label>
                          <input type="password" name="pw" class="form-control" id="exampleInputPassword1" placeholder="Enter New Password">
                        </div>
                        <div class="form-group">
                          <label for="exampleInputPassword1">subject</label>
                          <input type="text" name="sub" class="form-control" id="exampleInputPassword1" placeholder="Enter Subject">
                        </div>
                        <div class="form-group">
                      <label>Branch</label>
                      &nbsp;
                        <select  name="branch"class="form-control">
                          <option>Branch</option>
                          <option value="cse">CSE</option>
                          <option value="ece">ECE</option>
                          <option value="me">Mech</option>
                          <option value="ce">CIVIL</option>
                          <option value="eee">EEE</option>
                        </select>
                      </div>
                      <div class="form-group">
                    <label>Year</label>
                    &nbsp;
                      <select  name="year"class="form-control">
                        <option>Year</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                      </select>
                    </div>
                    <div class="row">
                    <div class="col-md-2">
                      <div class="form-group">
                    <label> Classes on mon:</label>
                    &nbsp;
                      <select  name="m"class="form-control">
                        <option>Classes</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                      </select>
                    </div>
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                    <label> Tue:</label>
                    &nbsp;
                      <select  name="t"class="form-control">
                        <option>Classes</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                      </select>
                    </div>
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                    <label> Wed:</label>
                    &nbsp;
                      <select  name="w"class="form-control">
                        <option>Classes</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                      </select>
                    </div>
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                    <label>Thu:</label>
                    &nbsp;
                      <select  name="th"class="form-control">
                        <option>Classes</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                      </select>
                    </div>
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                    <label>Fri:</label>
                    &nbsp;
                      <select  name="f"class="form-control">
                        <option>Classes</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5">5</option>
                        <option value="6">6</option>
                        <option value="7">7</option>
                        <option value="8">8</option>
                      </select>
                    </div>
                    </div>
                  </div>

                    <!--<div class="form-group">
                  <label>Section</label>
                  &nbsp;
                    <select  name="sec"class="form-control">
                      <option>sec</option>
                      <option value="a">A</option>
                      <option value="b">B</option>
                      <option value="c">C</option>
                      <option value="d">D</option>
                      <option value="e">E</option>
                    </select>
                  </div>-->


                        <button type="submit" name="submit" class="btn btn-success mr-2">Submit</button>
                        <button class="btn btn-light">Cancel</button>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <?php
        if(isset($_POST['submit']))
        {
        $user=$_SESSION['username'];
        $conn=new mysqli("localhost","root","","attn");
        $sel=mysqli_query($conn,"select * from staffinfo");
        while($row=mysqli_fetch_assoc($sel))
        {
         if($row['name']==$_POST['name'])
         {
           echo '<script>alert("Student Already Exists");</script>';
         }
         else {
           $name=$_POST['fn'];
           $passwd=$_POST['pw'];
           $subj=$_POST['sub'];
           $year=$_POST['year'];
           $branch=$_POST['branch'];
           $m=$_POST['m'];$t=$_POST['t'];$w=$_POST['w'];$th=$_POST['th'];$f=$_POST['f'];
           $inssel=mysqli_query($conn,"INSERT into `staffinfo`(`name`,`passwd`,`branch`,`subj`,`year`,`m`,`t`,`w`,`th`,`f`) values('$name','$passwd','$branch','$subj','$year','$m','$t','$w','$th','$f')");
           if($inssel)
           {
             echo '<script>alert("Student Added");</script>';
           }
         }

      }
    }?>
        <!-- content-wrapper ends -->
        <!-- partial:../../partials/_footer.html -->
        <footer class="footer">
          <div class="container-fluid clearfix">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright © 2018
              <a href="http://www.bootstrapdash.com/" target="_blank">Bootstrapdash</a>. All rights reserved.</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with
              <i class="mdi mdi-heart text-danger"></i>
            </span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="../../vendors/js/vendor.bundle.base.js"></script>
  <script src="../../vendors/js/vendor.bundle.addons.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page-->
  <!-- End plugin js for this page-->
  <!-- inject:js -->
  <script src="../../js/off-canvas.js"></script>
  <script src="../../js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page-->
  <!-- End custom js for this page-->
</body>

</html>
